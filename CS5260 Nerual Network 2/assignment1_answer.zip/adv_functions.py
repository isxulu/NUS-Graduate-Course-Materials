import torch


def create_adversarial_pattern(image, label, model, criterion):
    """Create signed gradient of an image

    Args:
        image (Tensor): image; shape=[C, H, W]
        label (int): label of the image
        model: pre-trained model
        criterion: criterion for computing loss

    Return:
        signed_grad: signed gradient of input image

    Hints:
        1. Pay attention to the input shape of model
        2. Pay attention to the label shape for calculating loss
        3. use loss.backward() or torch.autograd.grad() to get gradient of a tensor
    """

    signed_grad = None
    model.eval()

    ################################
    # Your code starts here
    ################################
    x = image.unsqueeze(0).requires_grad_(True)
    logits = model(x)
    loss = criterion(logits, torch.LongTensor([label]))

    use_backward = True
    if use_backward:
        loss.backward()
        x_grad = x.grad
    else:
        x_grad = torch.autograd.grad(outputs=[loss], inputs=[x])[0]
    signed_grad = torch.sign(x_grad).squeeze(0)

    ################################
    # Your code ends here
    ################################
    assert signed_grad.shape == image.shape
    return signed_grad


def create_adversarial_sample(image, eps, perturbation):
    """ Create an adversarial sample by adding noise to an image
    """
    adv_image = None

    ################################
    # Your code starts here
    ################################

    adv_image = image + eps * perturbation
    adv_image.clamp_(0, 1)

    ################################
    # Your code ends here
    ################################
    assert adv_image.shape == image.shape
    return adv_image
